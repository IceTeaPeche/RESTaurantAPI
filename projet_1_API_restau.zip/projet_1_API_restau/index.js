https://api.postman.com/collections/30566124-81f5fa87-aed4-446b-8489-1ebd86990ea2?access_key=PMAT-01HDPX3JC8BSDDHH1E7MP7BCK3

const { error } = require('console');
const express = require('express');
const { connect } = require('http2');


const mysql = require("mysql2");

const connection = mysql.createConnection({
    host: 'localhost', // Adresse du serveur MySQL
    user: 'root',
    password: 'Ethan33380',
    database: 'Restaurantsql'
});


connection.connect((err) => {
    if (err) {
        console.error('Erreur de connexion à la base de données : ' + err.stack);
        return;
    }
    console.log('Connecté à la base de données MySQL');
});

const app = express()
const port = 3000
app.use(express.json())

app.listen(port, () => console.log('notre application Node est démarrée sur : http://localhost:3000'))


//-------------------------------------------------------------------------------------------------------------------------//








//items-------------------------------------------------------------------------------------------------------------------------------------------------------

//----GET items
app.get('/items', (req, res) => {
    const parameters = req.query.parameters;

    if (!parameters) {
        connection.query('SELECT * FROM items', (err, rows, fields) => {
            if (err) throw err;
            res.send(rows);
        });
    } else {
        const sqlQuerypara = `SELECT nom_items, description_items, price_items FROM Items WHERE ${parameters}`;
        connection.query(sqlQuerypara, (err, result, fields) => {
            if (err) {
                console.error(err);
                res.status(500).send('Internal Server Error');
            } else {
                res.send(result);
            }
        });
    }
});

//----GET items:id
app.get('/items/:id_items', (req, res) => {
    const idItems = req.params.id_items;


    const sqlQueryid = 'SELECT nom_items, description_items, price_items FROM Items WHERE idItems = ?';
    connection.query(sqlQueryid, [idItems], (err, result, fields) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//http://localhost:3000/items
//http://localhost:3000/items?parameters=nom_items='BEER'

//----delete items
app.delete('/items/:id_items', (req, res) => {
    const idItems = req.params.id_items;


    const sqlQueryid = 'DELETE FROM Items WHERE idItems = ?';
    connection.query(sqlQueryid, [idItems], (err, result, fields) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//----créer items
app.post('/items/', (req, res) => {
    const itemsid = req.body.id;
    const nom_items = req.body.nom;
    const description_items = req.body.description;
    const price_items = req.body.price;
    const cat_items = req.body.cat_i; 

    const sqlQuery = 'INSERT INTO Items values(?,?,?,?,?);';
    connection.query(sqlQuery, [itemsid, nom_items, description_items, price_items, cat_items], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

// {
//     "id": 26,
//     "nom": "cake",
//     "description": "cake a la banane et la cerise",
//     "price" : "44€",
//     "cat_i": 5
// }


//----modifier items
app.put('/items/:id', (req, res) => {
    const itemsid = req.params.id;
    const nom_items = req.body.nom;
    const description_items = req.body.description;
    const price_items = req.body.price;
    const cat_items = req.body.cat_i; 

    const sqlQuery = 'UPDATE Items SET nom_items = ?, description_items = ?, price_items = ?, cat_items = ? WHERE iditems = ?;';
    connection.query(sqlQuery, [nom_items, description_items, price_items, cat_items, itemsid], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

// {
//     "nom": "NouveauNom",
//     "description": "NouvelleDescription",
//     "price": "29.99€",
//     "cat_i": 122
// }





//catégories-----------------------------------------------------------------------------------------------------------------------------------------------------------

//----GET catégorie
app.get('/categories/', (req,res) => {

    connection.query('SELECT name_category, nom_items, description_items ,price_items FROM category INNER JOIN Items ON id_category = Items.cat_items;', (err, result, fields) =>{
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    
    })
}
)

//----GET catégorie:id
app.get('/categories/:id_cate', (req, res) => {
    const idcate = req.params.id_cate;


    const sqlQueryid = 'SELECT name_category, nom_items, description_items ,price_items FROM category INNER JOIN Items ON id_category = ? = Items.cat_items ';
    connection.query(sqlQueryid, [idcate], (err, result, fields) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//----delete catégorie
app.delete('/categories/:cate_id', (req, res) => {
    const cateId = req.params.cate_id;

    const sqlQueryDelete = 'DELETE FROM category WHERE id_category = ?';
    connection.query(sqlQueryDelete, [cateId], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//----créer catégorie
app.post('/categories/', (req, res) => {
    const id_category = req.body.id;
    const name_category = req.body.nom;
    const items_category = req.body.cat_i; 

    const sqlQuery = 'INSERT INTO category values(?,?,?);';
    connection.query(sqlQuery, [id_category, name_category, items_category], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//----modifier catégorie
app.put('/categories/:cate_id', (req, res) => {
    const cateid = req.params.cate_id;
    const name_category = req.body.nom;
    const cat_items = req.body.cat_i; 

    const sqlQuery = 'UPDATE category SET name_category = ?, items_category = ? WHERE id_category = ?;';
    connection.query(sqlQuery, [name_category, cat_items, cateid,], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

// "nom": "NouveauNom",
// "cat_i": 122




//formulas------------------------------------------------------------------------------------------------------------------------------------------------------

//----GET formulas
app.get('/formulas', (req, res) => {
    const parameters = req.query.parameters;
    

    if (!parameters) {
        connection.query('SELECT name_formulas, price_formulas  FROM formulas', (err, result, fields) =>{
            if (err) {
                console.error(err);
                res.status(500).send('Internal Server Error');
            } else {
                res.send(result);
            }
        });
    } else {
        const sqlQuerypara = `SELECT name_formulas, price_formulas  FROM formulas WHERE ${parameters}`;
        connection.query(sqlQuerypara, (err, result, fields) => {
            if (err) {
                console.error(err);
                res.status(500).send('Internal Server Error');
            } else {
                res.send(result);
            }
        });
    }
});

//http://localhost:3000/formulas?parameters=price_formulas>19

//----GET formulas:id
app.get('/formulas/:id', (req, res) => {
    const id_formulas = req.params.id;


    const sqlQueryid = 'SELECT name_formulas, price_formulas, category_formulas FROM formulas WHERE id_formulas = ?';
    connection.query(sqlQueryid, [id_formulas], (err, result, fields) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//----delete formulas
app.delete('/formulas/:id', (req, res) => {
    const id_formulas = req.params.id;


    const sqlQueryid = 'DELETE FROM formulas WHERE id_formulas = ?';
    connection.query(sqlQueryid, [id_formulas], (err, result, fields) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//----créer formulas
app.post('/formulas/', (req, res) => {
    const id_formulas = req.body.id;
    const name_formulas = req.body.nom;
    const price_formulas = req.body.price
    const category_formulas = req.body.cat_i; 

    const sqlQuery = 'INSERT INTO formulas values(?,?,?,?);';
    connection.query(sqlQuery, [id_formulas, name_formulas, price_formulas, category_formulas], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

//----modifier formulas
app.put('/formulas/:id', (req, res) => {
    const id_formulas = req.params.id;
    const name_formulas = req.body.nom;
    const category_formulas = req.body.cat_i; 
    const price_formulas = req.body.price

    const sqlQuery = 'UPDATE formulas SET name_formulas = ?, category_formulas = ?, price_formulas = ? WHERE id_formulas = ?;';
    connection.query(sqlQuery, [name_formulas, category_formulas,price_formulas, id_formulas,], (err, result) => {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.send(result);
        }
    });
});

// {
//     "nom": "NouveauNom",
//     "cat_i": 122,
//     "price" : "12€"
// }




